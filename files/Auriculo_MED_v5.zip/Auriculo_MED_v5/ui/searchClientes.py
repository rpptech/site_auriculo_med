# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'searchClientes.ui'
##
## Created by: Qt User Interface Compiler version 6.1.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *  # type: ignore
from PySide6.QtGui import *  # type: ignore
from PySide6.QtWidgets import *  # type: ignore


class Ui_SearchClients(object):
    def setupUi(self, SearchClients):
        if not SearchClients.objectName():
            SearchClients.setObjectName(u"SearchClients")
        SearchClients.resize(951, 429)
        self.tableWidget_clientsSearch = QTableWidget(SearchClients)
        if (self.tableWidget_clientsSearch.rowCount() < 1):
            self.tableWidget_clientsSearch.setRowCount(1)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget_clientsSearch.setVerticalHeaderItem(0, __qtablewidgetitem)
        self.tableWidget_clientsSearch.setObjectName(u"tableWidget_clientsSearch")
        self.tableWidget_clientsSearch.setGeometry(QRect(20, 120, 891, 251))
        self.tableWidget_clientsSearch.setFrameShape(QFrame.NoFrame)
        self.tableWidget_clientsSearch.setFrameShadow(QFrame.Plain)
        self.tableWidget_clientsSearch.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tableWidget_clientsSearch.setAlternatingRowColors(False)
        self.tableWidget_clientsSearch.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tableWidget_clientsSearch.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget_clientsSearch.setGridStyle(Qt.DashDotDotLine)
        self.tableWidget_clientsSearch.setSortingEnabled(True)
        self.bt_okSearch = QPushButton(SearchClients)
        self.bt_okSearch.setObjectName(u"bt_okSearch")
        self.bt_okSearch.setGeometry(QRect(720, 390, 75, 23))
        self.bt_cancelSearch = QPushButton(SearchClients)
        self.bt_cancelSearch.setObjectName(u"bt_cancelSearch")
        self.bt_cancelSearch.setGeometry(QRect(830, 390, 75, 23))
        self.label_msgSearch = QLabel(SearchClients)
        self.label_msgSearch.setObjectName(u"label_msgSearch")
        self.label_msgSearch.setGeometry(QRect(220, 30, 111, 16))
        self.bt_clienteSearch = QCommandLinkButton(SearchClients)
        self.bt_clienteSearch.setObjectName(u"bt_clienteSearch")
        self.bt_clienteSearch.setGeometry(QRect(50, 20, 161, 40))
        font = QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setKerning(True)
        self.bt_clienteSearch.setFont(font)
        icon = QIcon()
        icon.addFile(u"files/icons/search_people.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_clienteSearch.setIcon(icon)
        self.bt_clienteSearch.setIconSize(QSize(25, 25))
        self.lineEdit_nomeSearch = QLineEdit(SearchClients)
        self.lineEdit_nomeSearch.setObjectName(u"lineEdit_nomeSearch")
        self.lineEdit_nomeSearch.setGeometry(QRect(80, 70, 831, 24))
        font1 = QFont()
        font1.setPointSize(12)
        font1.setBold(False)
        self.lineEdit_nomeSearch.setFont(font1)
        self.label_nome_Search = QLabel(SearchClients)
        self.label_nome_Search.setObjectName(u"label_nome_Search")
        self.label_nome_Search.setGeometry(QRect(20, 70, 51, 18))
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        self.label_nome_Search.setFont(font2)
        self.label_nome_Search.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.bt_DelPaciente = QPushButton(SearchClients)
        self.bt_DelPaciente.setObjectName(u"bt_DelPaciente")
        self.bt_DelPaciente.setGeometry(QRect(420, 19, 151, 41))
        font3 = QFont()
        font3.setPointSize(10)
        font3.setBold(True)
        font3.setUnderline(False)
        font3.setStrikeOut(False)
        self.bt_DelPaciente.setFont(font3)
        self.bt_DelPaciente.setStyleSheet(u"")
        icon1 = QIcon()
        icon1.addFile(u"../files/icons/male-user-remove_96.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_DelPaciente.setIcon(icon1)
        self.bt_DelPaciente.setIconSize(QSize(35, 35))
        self.label_msg = QLabel(SearchClients)
        self.label_msg.setObjectName(u"label_msg")
        self.label_msg.setGeometry(QRect(580, 30, 321, 21))
        self.label_msg.setFont(font2)
        self.label_msg.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
#if QT_CONFIG(shortcut)
        self.label_nome_Search.setBuddy(self.lineEdit_nomeSearch)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(SearchClients)

        QMetaObject.connectSlotsByName(SearchClients)
    # setupUi

    def retranslateUi(self, SearchClients):
        SearchClients.setWindowTitle(QCoreApplication.translate("SearchClients", u"Clientes Cadastrados", None))
        ___qtablewidgetitem = self.tableWidget_clientsSearch.verticalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("SearchClients", u"1", None));
        self.bt_okSearch.setText(QCoreApplication.translate("SearchClients", u"Ok", None))
        self.bt_cancelSearch.setText(QCoreApplication.translate("SearchClients", u"Cancel", None))
        self.label_msgSearch.setText("")
#if QT_CONFIG(tooltip)
        self.bt_clienteSearch.setToolTip("")
#endif // QT_CONFIG(tooltip)
        self.bt_clienteSearch.setText(QCoreApplication.translate("SearchClients", u"&Procurar Cliente", None))
        self.label_nome_Search.setText(QCoreApplication.translate("SearchClients", u"&Nome", None))
        self.bt_DelPaciente.setText(QCoreApplication.translate("SearchClients", u"Apagar Paciente", None))
        self.label_msg.setText("")
    # retranslateUi

