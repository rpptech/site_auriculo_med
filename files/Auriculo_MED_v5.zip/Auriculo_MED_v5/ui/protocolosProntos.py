# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'protocolosProntos.ui'
##
## Created by: Qt User Interface Compiler version 6.1.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *  # type: ignore
from PySide6.QtGui import *  # type: ignore
from PySide6.QtWidgets import *  # type: ignore


class Ui_ProtocolosProntos(object):
    def setupUi(self, ProtocolosProntos):
        if not ProtocolosProntos.objectName():
            ProtocolosProntos.setObjectName(u"ProtocolosProntos")
        ProtocolosProntos.resize(850, 500)
        ProtocolosProntos.setMinimumSize(QSize(850, 500))
        ProtocolosProntos.setMaximumSize(QSize(850, 500))
        self.frame = QFrame(ProtocolosProntos)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(9, 9, 821, 481))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.bt_cancel = QPushButton(self.frame)
        self.bt_cancel.setObjectName(u"bt_cancel")
        self.bt_cancel.setGeometry(QRect(580, 450, 75, 24))
        font = QFont()
        font.setPointSize(10)
        font.setBold(True)
        self.bt_cancel.setFont(font)
        self.label_queixa_3 = QLabel(self.frame)
        self.label_queixa_3.setObjectName(u"label_queixa_3")
        self.label_queixa_3.setGeometry(QRect(440, 50, 141, 20))
        self.label_queixa_3.setFont(font)
        self.label_queixa_3.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.listSintomas1 = QListWidget(self.frame)
        self.listSintomas1.setObjectName(u"listSintomas1")
        self.listSintomas1.setGeometry(QRect(0, 70, 191, 370))
        font1 = QFont()
        font1.setPointSize(10)
        self.listSintomas1.setFont(font1)
        self.listSintomas1.setSelectionMode(QAbstractItemView.SingleSelection)
        self.label_35 = QLabel(self.frame)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setGeometry(QRect(10, 10, 371, 25))
        font2 = QFont()
        font2.setPointSize(17)
        font2.setBold(True)
        font2.setItalic(True)
        font2.setUnderline(False)
        self.label_35.setFont(font2)
        self.label_35.setStyleSheet(u"color: rgb(0, 85, 255);")
        self.listSintomas2 = QListWidget(self.frame)
        self.listSintomas2.setObjectName(u"listSintomas2")
        self.listSintomas2.setGeometry(QRect(209, 70, 211, 370))
        self.listSintomas2.setFont(font1)
        self.listSintomas2.setSelectionMode(QAbstractItemView.SingleSelection)
        self.label_1 = QLabel(self.frame)
        self.label_1.setObjectName(u"label_1")
        self.label_1.setGeometry(QRect(0, 50, 141, 20))
        self.label_1.setFont(font)
        self.label_1.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.bt_add = QPushButton(self.frame)
        self.bt_add.setObjectName(u"bt_add")
        self.bt_add.setGeometry(QRect(660, 30, 141, 31))
        self.bt_add.setFont(font)
        icon = QIcon()
        icon.addFile(u"./files/icons/arrow_right-48.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_add.setIcon(icon)
        self.bt_add.setIconSize(QSize(20, 20))
        self.listPontos = QListWidget(self.frame)
        self.listPontos.setObjectName(u"listPontos")
        self.listPontos.setEnabled(False)
        self.listPontos.setGeometry(QRect(439, 70, 361, 370))
        self.listPontos.setFont(font1)
        self.listPontos.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(210, 50, 141, 20))
        self.label_2.setFont(font)
        self.label_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.retranslateUi(ProtocolosProntos)

        QMetaObject.connectSlotsByName(ProtocolosProntos)
    # setupUi

    def retranslateUi(self, ProtocolosProntos):
        ProtocolosProntos.setWindowTitle(QCoreApplication.translate("ProtocolosProntos", u"Protocolos", None))
        self.bt_cancel.setText(QCoreApplication.translate("ProtocolosProntos", u"Cancelar", None))
        self.label_queixa_3.setText(QCoreApplication.translate("ProtocolosProntos", u"Pontos", None))
        self.label_35.setText(QCoreApplication.translate("ProtocolosProntos", u"Protocolos", None))
        self.label_1.setText(QCoreApplication.translate("ProtocolosProntos", u"Sintomas Complexos", None))
        self.bt_add.setText(QCoreApplication.translate("ProtocolosProntos", u" Adicionar pontos", None))
        self.label_2.setText(QCoreApplication.translate("ProtocolosProntos", u"Sintomas", None))
    # retranslateUi

