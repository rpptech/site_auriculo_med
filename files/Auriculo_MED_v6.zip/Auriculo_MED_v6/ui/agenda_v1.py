# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'agenda_v1.ui'
##
## Created by: Qt User Interface Compiler version 6.1.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *  # type: ignore
from PySide6.QtGui import *  # type: ignore
from PySide6.QtWidgets import *  # type: ignore


class Ui_Agenda(object):
    def setupUi(self, Agenda):
        if not Agenda.objectName():
            Agenda.setObjectName(u"Agenda")
        Agenda.resize(900, 530)
        Agenda.setMinimumSize(QSize(900, 530))
        Agenda.setMaximumSize(QSize(900, 530))
        self.horizontalLayout = QHBoxLayout(Agenda)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.frame = QFrame(Agenda)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.bt_save = QPushButton(self.frame)
        self.bt_save.setObjectName(u"bt_save")
        self.bt_save.setGeometry(QRect(260, 460, 71, 31))
        font = QFont()
        font.setPointSize(10)
        font.setBold(False)
        self.bt_save.setFont(font)
        self.bt_save.setStyleSheet(u"")
        icon = QIcon()
        icon.addFile(u"./files/icons/saveBlue-128.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_save.setIcon(icon)
        self.bt_save.setIconSize(QSize(25, 25))
        self.bt_sair = QPushButton(self.frame)
        self.bt_sair.setObjectName(u"bt_sair")
        self.bt_sair.setGeometry(QRect(350, 460, 71, 31))
        self.bt_sair.setFont(font)
        self.bt_sair.setStyleSheet(u"border:none\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"./files/icons/exit-64.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_sair.setIcon(icon1)
        self.bt_sair.setIconSize(QSize(25, 25))
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(20, 300, 10, 20))
        self.label.setPixmap(QPixmap(u"./files/icons/pt_red_10.png"))
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(34, 301, 171, 16))

        self.horizontalLayout.addWidget(self.frame)

        self.frame_2 = QFrame(Agenda)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.tableWidget = QTableWidget(self.frame_2)
        if (self.tableWidget.columnCount() < 3):
            self.tableWidget.setColumnCount(3)
        __qtablewidgetitem = QTableWidgetItem()
        __qtablewidgetitem.setText(u"Data_antes");
        __qtablewidgetitem.setBackground(QColor(255, 255, 255));
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        if (self.tableWidget.rowCount() < 48):
            self.tableWidget.setRowCount(48)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(5, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(6, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(7, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(8, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(9, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(10, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(11, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(12, __qtablewidgetitem15)
        __qtablewidgetitem16 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(13, __qtablewidgetitem16)
        __qtablewidgetitem17 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(14, __qtablewidgetitem17)
        __qtablewidgetitem18 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(15, __qtablewidgetitem18)
        __qtablewidgetitem19 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(16, __qtablewidgetitem19)
        __qtablewidgetitem20 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(17, __qtablewidgetitem20)
        __qtablewidgetitem21 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(18, __qtablewidgetitem21)
        __qtablewidgetitem22 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(19, __qtablewidgetitem22)
        __qtablewidgetitem23 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(20, __qtablewidgetitem23)
        __qtablewidgetitem24 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(21, __qtablewidgetitem24)
        __qtablewidgetitem25 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(22, __qtablewidgetitem25)
        __qtablewidgetitem26 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(23, __qtablewidgetitem26)
        __qtablewidgetitem27 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(24, __qtablewidgetitem27)
        __qtablewidgetitem28 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(25, __qtablewidgetitem28)
        __qtablewidgetitem29 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(26, __qtablewidgetitem29)
        __qtablewidgetitem30 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(27, __qtablewidgetitem30)
        __qtablewidgetitem31 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(28, __qtablewidgetitem31)
        __qtablewidgetitem32 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(29, __qtablewidgetitem32)
        __qtablewidgetitem33 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(30, __qtablewidgetitem33)
        __qtablewidgetitem34 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(31, __qtablewidgetitem34)
        __qtablewidgetitem35 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(32, __qtablewidgetitem35)
        __qtablewidgetitem36 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(33, __qtablewidgetitem36)
        __qtablewidgetitem37 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(34, __qtablewidgetitem37)
        __qtablewidgetitem38 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(35, __qtablewidgetitem38)
        __qtablewidgetitem39 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(36, __qtablewidgetitem39)
        __qtablewidgetitem40 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(37, __qtablewidgetitem40)
        __qtablewidgetitem41 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(38, __qtablewidgetitem41)
        __qtablewidgetitem42 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(39, __qtablewidgetitem42)
        __qtablewidgetitem43 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(40, __qtablewidgetitem43)
        __qtablewidgetitem44 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(41, __qtablewidgetitem44)
        __qtablewidgetitem45 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(42, __qtablewidgetitem45)
        __qtablewidgetitem46 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(43, __qtablewidgetitem46)
        __qtablewidgetitem47 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(44, __qtablewidgetitem47)
        __qtablewidgetitem48 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(45, __qtablewidgetitem48)
        __qtablewidgetitem49 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(46, __qtablewidgetitem49)
        __qtablewidgetitem50 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(47, __qtablewidgetitem50)
        brush = QBrush(QColor(0, 0, 0, 255))
        brush.setStyle(Qt.NoBrush)
        __qtablewidgetitem51 = QTableWidgetItem()
        __qtablewidgetitem51.setForeground(brush);
        self.tableWidget.setItem(0, 0, __qtablewidgetitem51)
        brush1 = QBrush(QColor(0, 0, 0, 255))
        brush1.setStyle(Qt.NoBrush)
        __qtablewidgetitem52 = QTableWidgetItem()
        __qtablewidgetitem52.setForeground(brush1);
        self.tableWidget.setItem(1, 0, __qtablewidgetitem52)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setEnabled(True)
        self.tableWidget.setGeometry(QRect(30, 30, 361, 471))
        font1 = QFont()
        font1.setPointSize(10)
        self.tableWidget.setFont(font1)
        self.tableWidget.setFrameShape(QFrame.StyledPanel)
        self.tableWidget.setFrameShadow(QFrame.Sunken)
        self.tableWidget.setLineWidth(1)
        self.tableWidget.setMidLineWidth(0)
        self.tableWidget.setAlternatingRowColors(True)
        self.tableWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tableWidget.setShowGrid(True)
        self.bt_dayBefore = QPushButton(self.frame_2)
        self.bt_dayBefore.setObjectName(u"bt_dayBefore")
        self.bt_dayBefore.setGeometry(QRect(90, 0, 30, 30))
        self.bt_dayBefore.setStyleSheet(u"border: none")
        icon2 = QIcon()
        icon2.addFile(u"./files/icons/left_blue-32.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_dayBefore.setIcon(icon2)
        self.bt_dayBefore.setIconSize(QSize(25, 25))
        self.bt_dayNext = QPushButton(self.frame_2)
        self.bt_dayNext.setObjectName(u"bt_dayNext")
        self.bt_dayNext.setGeometry(QRect(280, 0, 30, 30))
        self.bt_dayNext.setStyleSheet(u"border: none")
        icon3 = QIcon()
        icon3.addFile(u"./files/icons/right_blue-32.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_dayNext.setIcon(icon3)
        self.bt_dayNext.setIconSize(QSize(25, 25))

        self.horizontalLayout.addWidget(self.frame_2)


        self.retranslateUi(Agenda)

        QMetaObject.connectSlotsByName(Agenda)
    # setupUi

    def retranslateUi(self, Agenda):
        Agenda.setWindowTitle(QCoreApplication.translate("Agenda", u"Agenda", None))
        self.bt_save.setText(QCoreApplication.translate("Agenda", u"Salvar", None))
        self.bt_sair.setText(QCoreApplication.translate("Agenda", u"Sair", None))
        self.label.setText("")
        self.label_2.setText(QCoreApplication.translate("Agenda", u"dia com consulta marcada", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem.setText(QCoreApplication.translate("Agenda", u"Data", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("Agenda", u"Data_depois", None));
        ___qtablewidgetitem2 = self.tableWidget.verticalHeaderItem(0)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("Agenda", u"00:00", None));
        ___qtablewidgetitem3 = self.tableWidget.verticalHeaderItem(1)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("Agenda", u"00:30", None));
        ___qtablewidgetitem4 = self.tableWidget.verticalHeaderItem(2)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("Agenda", u"01:00", None));
        ___qtablewidgetitem5 = self.tableWidget.verticalHeaderItem(3)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("Agenda", u"01:30", None));
        ___qtablewidgetitem6 = self.tableWidget.verticalHeaderItem(4)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("Agenda", u"02:00", None));
        ___qtablewidgetitem7 = self.tableWidget.verticalHeaderItem(5)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("Agenda", u"02:30", None));
        ___qtablewidgetitem8 = self.tableWidget.verticalHeaderItem(6)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("Agenda", u"03:00", None));
        ___qtablewidgetitem9 = self.tableWidget.verticalHeaderItem(7)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("Agenda", u"03:30", None));
        ___qtablewidgetitem10 = self.tableWidget.verticalHeaderItem(8)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("Agenda", u"04:00", None));
        ___qtablewidgetitem11 = self.tableWidget.verticalHeaderItem(9)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("Agenda", u"04:30", None));
        ___qtablewidgetitem12 = self.tableWidget.verticalHeaderItem(10)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("Agenda", u"05:00", None));
        ___qtablewidgetitem13 = self.tableWidget.verticalHeaderItem(11)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("Agenda", u"05:30", None));
        ___qtablewidgetitem14 = self.tableWidget.verticalHeaderItem(12)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("Agenda", u"06:00", None));
        ___qtablewidgetitem15 = self.tableWidget.verticalHeaderItem(13)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("Agenda", u"06:30", None));
        ___qtablewidgetitem16 = self.tableWidget.verticalHeaderItem(14)
        ___qtablewidgetitem16.setText(QCoreApplication.translate("Agenda", u"07:00", None));
        ___qtablewidgetitem17 = self.tableWidget.verticalHeaderItem(15)
        ___qtablewidgetitem17.setText(QCoreApplication.translate("Agenda", u"07:30", None));
        ___qtablewidgetitem18 = self.tableWidget.verticalHeaderItem(16)
        ___qtablewidgetitem18.setText(QCoreApplication.translate("Agenda", u"08:00", None));
        ___qtablewidgetitem19 = self.tableWidget.verticalHeaderItem(17)
        ___qtablewidgetitem19.setText(QCoreApplication.translate("Agenda", u"08:30", None));
        ___qtablewidgetitem20 = self.tableWidget.verticalHeaderItem(18)
        ___qtablewidgetitem20.setText(QCoreApplication.translate("Agenda", u"09:00", None));
        ___qtablewidgetitem21 = self.tableWidget.verticalHeaderItem(19)
        ___qtablewidgetitem21.setText(QCoreApplication.translate("Agenda", u"09:30", None));
        ___qtablewidgetitem22 = self.tableWidget.verticalHeaderItem(20)
        ___qtablewidgetitem22.setText(QCoreApplication.translate("Agenda", u"10:00", None));
        ___qtablewidgetitem23 = self.tableWidget.verticalHeaderItem(21)
        ___qtablewidgetitem23.setText(QCoreApplication.translate("Agenda", u"10:30", None));
        ___qtablewidgetitem24 = self.tableWidget.verticalHeaderItem(22)
        ___qtablewidgetitem24.setText(QCoreApplication.translate("Agenda", u"11:00", None));
        ___qtablewidgetitem25 = self.tableWidget.verticalHeaderItem(23)
        ___qtablewidgetitem25.setText(QCoreApplication.translate("Agenda", u"11:30", None));
        ___qtablewidgetitem26 = self.tableWidget.verticalHeaderItem(24)
        ___qtablewidgetitem26.setText(QCoreApplication.translate("Agenda", u"12:00", None));
        ___qtablewidgetitem27 = self.tableWidget.verticalHeaderItem(25)
        ___qtablewidgetitem27.setText(QCoreApplication.translate("Agenda", u"12:30", None));
        ___qtablewidgetitem28 = self.tableWidget.verticalHeaderItem(26)
        ___qtablewidgetitem28.setText(QCoreApplication.translate("Agenda", u"13:00", None));
        ___qtablewidgetitem29 = self.tableWidget.verticalHeaderItem(27)
        ___qtablewidgetitem29.setText(QCoreApplication.translate("Agenda", u"13:30", None));
        ___qtablewidgetitem30 = self.tableWidget.verticalHeaderItem(28)
        ___qtablewidgetitem30.setText(QCoreApplication.translate("Agenda", u"14:00", None));
        ___qtablewidgetitem31 = self.tableWidget.verticalHeaderItem(29)
        ___qtablewidgetitem31.setText(QCoreApplication.translate("Agenda", u"14:30", None));
        ___qtablewidgetitem32 = self.tableWidget.verticalHeaderItem(30)
        ___qtablewidgetitem32.setText(QCoreApplication.translate("Agenda", u"15:00", None));
        ___qtablewidgetitem33 = self.tableWidget.verticalHeaderItem(31)
        ___qtablewidgetitem33.setText(QCoreApplication.translate("Agenda", u"15:30", None));
        ___qtablewidgetitem34 = self.tableWidget.verticalHeaderItem(32)
        ___qtablewidgetitem34.setText(QCoreApplication.translate("Agenda", u"16:00", None));
        ___qtablewidgetitem35 = self.tableWidget.verticalHeaderItem(33)
        ___qtablewidgetitem35.setText(QCoreApplication.translate("Agenda", u"16:30", None));
        ___qtablewidgetitem36 = self.tableWidget.verticalHeaderItem(34)
        ___qtablewidgetitem36.setText(QCoreApplication.translate("Agenda", u"17:00", None));
        ___qtablewidgetitem37 = self.tableWidget.verticalHeaderItem(35)
        ___qtablewidgetitem37.setText(QCoreApplication.translate("Agenda", u"17:30", None));
        ___qtablewidgetitem38 = self.tableWidget.verticalHeaderItem(36)
        ___qtablewidgetitem38.setText(QCoreApplication.translate("Agenda", u"18:00", None));
        ___qtablewidgetitem39 = self.tableWidget.verticalHeaderItem(37)
        ___qtablewidgetitem39.setText(QCoreApplication.translate("Agenda", u"18:30", None));
        ___qtablewidgetitem40 = self.tableWidget.verticalHeaderItem(38)
        ___qtablewidgetitem40.setText(QCoreApplication.translate("Agenda", u"19:00", None));
        ___qtablewidgetitem41 = self.tableWidget.verticalHeaderItem(39)
        ___qtablewidgetitem41.setText(QCoreApplication.translate("Agenda", u"19:30", None));
        ___qtablewidgetitem42 = self.tableWidget.verticalHeaderItem(40)
        ___qtablewidgetitem42.setText(QCoreApplication.translate("Agenda", u"20:00", None));
        ___qtablewidgetitem43 = self.tableWidget.verticalHeaderItem(41)
        ___qtablewidgetitem43.setText(QCoreApplication.translate("Agenda", u"20:30", None));
        ___qtablewidgetitem44 = self.tableWidget.verticalHeaderItem(42)
        ___qtablewidgetitem44.setText(QCoreApplication.translate("Agenda", u"21:00", None));
        ___qtablewidgetitem45 = self.tableWidget.verticalHeaderItem(43)
        ___qtablewidgetitem45.setText(QCoreApplication.translate("Agenda", u"21:30", None));
        ___qtablewidgetitem46 = self.tableWidget.verticalHeaderItem(44)
        ___qtablewidgetitem46.setText(QCoreApplication.translate("Agenda", u"22:00", None));
        ___qtablewidgetitem47 = self.tableWidget.verticalHeaderItem(45)
        ___qtablewidgetitem47.setText(QCoreApplication.translate("Agenda", u"22:30", None));
        ___qtablewidgetitem48 = self.tableWidget.verticalHeaderItem(46)
        ___qtablewidgetitem48.setText(QCoreApplication.translate("Agenda", u"23:00", None));
        ___qtablewidgetitem49 = self.tableWidget.verticalHeaderItem(47)
        ___qtablewidgetitem49.setText(QCoreApplication.translate("Agenda", u"23:30", None));

        __sortingEnabled = self.tableWidget.isSortingEnabled()
        self.tableWidget.setSortingEnabled(False)
        self.tableWidget.setSortingEnabled(__sortingEnabled)

        self.bt_dayBefore.setText("")
        self.bt_dayNext.setText("")
    # retranslateUi

