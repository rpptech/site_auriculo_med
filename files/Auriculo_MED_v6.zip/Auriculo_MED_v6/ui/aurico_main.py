# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'aurico_main.ui'
##
## Created by: Qt User Interface Compiler version 6.1.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *  # type: ignore
from PySide6.QtGui import *  # type: ignore
from PySide6.QtWidgets import *  # type: ignore


class Ui_Auriculoterapia_Main(object):
    def setupUi(self, Auriculoterapia_Main):
        if not Auriculoterapia_Main.objectName():
            Auriculoterapia_Main.setObjectName(u"Auriculoterapia_Main")
        Auriculoterapia_Main.resize(800, 450)
        Auriculoterapia_Main.setMinimumSize(QSize(800, 450))
        Auriculoterapia_Main.setMaximumSize(QSize(800, 450))
        icon = QIcon()
        icon.addFile(u"././.designer/backup/files/icons/ear_icon_151378.ico", QSize(), QIcon.Normal, QIcon.Off)
        Auriculoterapia_Main.setWindowIcon(icon)
        Auriculoterapia_Main.setStyleSheet(u"")
        self.centralwidget = QWidget(Auriculoterapia_Main)
        self.centralwidget.setObjectName(u"centralwidget")
        self.widget = QWidget(self.centralwidget)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(360, 20, 421, 341))
        self.bt_NewClient = QCommandLinkButton(self.widget)
        self.bt_NewClient.setObjectName(u"bt_NewClient")
        self.bt_NewClient.setGeometry(QRect(30, 40, 471, 51))
        font = QFont()
        font.setPointSize(21)
        self.bt_NewClient.setFont(font)
        icon1 = QIcon()
        icon1.addFile(u"files/icons/edition.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_NewClient.setIcon(icon1)
        self.bt_NewClient.setIconSize(QSize(40, 40))
        self.bt_OpenClient = QCommandLinkButton(self.widget)
        self.bt_OpenClient.setObjectName(u"bt_OpenClient")
        self.bt_OpenClient.setGeometry(QRect(30, 120, 461, 51))
        font1 = QFont()
        font1.setPointSize(22)
        self.bt_OpenClient.setFont(font1)
        icon2 = QIcon()
        icon2.addFile(u"././.designer/backup/files/icons/binder.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_OpenClient.setIcon(icon2)
        self.bt_OpenClient.setIconSize(QSize(40, 40))
        self.bt_agenda = QCommandLinkButton(self.widget)
        self.bt_agenda.setObjectName(u"bt_agenda")
        self.bt_agenda.setGeometry(QRect(30, 200, 461, 51))
        self.bt_agenda.setFont(font1)
        icon3 = QIcon()
        icon3.addFile(u"././.designer/backup/files/icons/ear.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_agenda.setIcon(icon3)
        self.bt_agenda.setIconSize(QSize(40, 40))
        self.bt_help = QPushButton(self.widget)
        self.bt_help.setObjectName(u"bt_help")
        self.bt_help.setGeometry(QRect(320, 0, 101, 31))
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(False)
        self.bt_help.setFont(font2)
        self.bt_help.setStyleSheet(u"border: none")
        icon4 = QIcon()
        icon4.addFile(u"./files/icons/help-64.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_help.setIcon(icon4)
        self.bt_help.setIconSize(QSize(25, 25))
        self.bt_sair = QPushButton(self.centralwidget)
        self.bt_sair.setObjectName(u"bt_sair")
        self.bt_sair.setGeometry(QRect(630, 370, 151, 41))
        self.bt_sair.setFont(font2)
        self.bt_sair.setStyleSheet(u"border: none")
        icon5 = QIcon()
        icon5.addFile(u"./files/icons/exit-64.png", QSize(), QIcon.Normal, QIcon.Off)
        self.bt_sair.setIcon(icon5)
        self.bt_sair.setIconSize(QSize(30, 30))
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 20, 341, 331))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setPixmap(QPixmap(u"./files/logo_aurico.png"))
        self.label.setScaledContents(True)

        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)

        Auriculoterapia_Main.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(Auriculoterapia_Main)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 22))
        Auriculoterapia_Main.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(Auriculoterapia_Main)
        self.statusbar.setObjectName(u"statusbar")
        self.statusbar.setSizeGripEnabled(True)
        Auriculoterapia_Main.setStatusBar(self.statusbar)
        QWidget.setTabOrder(self.bt_NewClient, self.bt_OpenClient)
        QWidget.setTabOrder(self.bt_OpenClient, self.bt_agenda)
        QWidget.setTabOrder(self.bt_agenda, self.bt_help)
        QWidget.setTabOrder(self.bt_help, self.bt_sair)

        self.retranslateUi(Auriculoterapia_Main)

        QMetaObject.connectSlotsByName(Auriculoterapia_Main)
    # setupUi

    def retranslateUi(self, Auriculoterapia_Main):
        Auriculoterapia_Main.setWindowTitle(QCoreApplication.translate("Auriculoterapia_Main", u"Auriculoterapia_Principal", None))
#if QT_CONFIG(tooltip)
        self.bt_NewClient.setToolTip(QCoreApplication.translate("Auriculoterapia_Main", u"cadastro de novo paciente", None))
#endif // QT_CONFIG(tooltip)
        self.bt_NewClient.setText(QCoreApplication.translate("Auriculoterapia_Main", u" Novo Paciente", None))
#if QT_CONFIG(tooltip)
        self.bt_OpenClient.setToolTip(QCoreApplication.translate("Auriculoterapia_Main", u"consulta e altera\u00e7\u00e3o de pacientes j\u00e1 existentes", None))
#endif // QT_CONFIG(tooltip)
        self.bt_OpenClient.setText(QCoreApplication.translate("Auriculoterapia_Main", u"Pacientes", None))
#if QT_CONFIG(tooltip)
        self.bt_agenda.setToolTip(QCoreApplication.translate("Auriculoterapia_Main", u"abrir agenda de consultas", None))
#endif // QT_CONFIG(tooltip)
        self.bt_agenda.setText(QCoreApplication.translate("Auriculoterapia_Main", u"Agenda de Consultas", None))
#if QT_CONFIG(tooltip)
        self.bt_help.setToolTip(QCoreApplication.translate("Auriculoterapia_Main", u"Obter ajuda", None))
#endif // QT_CONFIG(tooltip)
        self.bt_help.setText(QCoreApplication.translate("Auriculoterapia_Main", u"Ajuda", None))
#if QT_CONFIG(tooltip)
        self.bt_sair.setToolTip(QCoreApplication.translate("Auriculoterapia_Main", u"sair do programa", None))
#endif // QT_CONFIG(tooltip)
        self.bt_sair.setText(QCoreApplication.translate("Auriculoterapia_Main", u" Sair do Programa", None))
        self.label.setText("")
    # retranslateUi

